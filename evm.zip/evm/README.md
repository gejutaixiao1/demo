# Twitter @0xgejutaixiao
# https://twitter.com/0xgejutaixiao

# telegram @gejutaixiao0x

**应该是能用所有EVM链**

# 依赖：
```
pip install web3



