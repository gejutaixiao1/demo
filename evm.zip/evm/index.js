const Web3 = require('web3');

// BSC节点
const bscNodeUrl = 'https://bscrpc.com';

const web3 = new Web3(new Web3.providers.HttpProvider(bscNodeUrl));

// 发送者私钥
const privateKey = '发送者私钥';

// 发送者地址
const senderAddress = '发送者地址';

// 接收者地址
const recipientAddress = '接收者地址';

// 转账金额（以Wei为单位）
const amountInWei = web3.utils.toWei('0', 'ether'); // 转账数量

// 备注打铭文信息
//data:,{"p":"bsc-20","op":"mint","tick":"123","amt":"123"}
const memo = 'memo';

const successLimit = 2; // 自定义成功转账数量


async function sendTransaction(nonce) {
  const gasPrice = web3.utils.toHex(web3.utils.toWei('5', 'gwei'));
  const gasLimit = web3.utils.toHex(25000);

  const txParams = {
    nonce: nonce,
    gasPrice: gasPrice,
    gasLimit: gasLimit,
    to: recipientAddress,
    value: web3.utils.toHex(amountInWei),
    data: web3.utils.utf8ToHex(memo),
  };

  try {
    const signedTx = await web3.eth.accounts.signTransaction(txParams, privateKey);
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

    console.log(`交易成功. Hash: ${receipt.transactionHash}`);
    return { success: true, hash: receipt.transactionHash };
  } catch (error) {
    console.error('发送交易时出错:', error.message);
    return { success: false, error: error.message };
  }
}

async function main() {
  try {
    // 获取发送者账户nonce
    const nonce = await web3.eth.getTransactionCount(senderAddress, 'pending');

    let successCount = 0;

    // 循环发送多次交易，直到成功转账数量达到限制
    for (let i = 0; i < 5; i++) { // 举例：最多尝试5次
      const result = await sendTransaction(nonce + i);
      if (result.success) {
        successCount++;
        console.log(`交易 ${successCount} 成功. Hash: ${result.hash}`);
      } else {
        console.log(`交易 ${i + 1} 失败. 原因: ${result.error}`);
      }

      if (successCount >= successLimit) {
        console.log(`已达到成功交易的上限.`);
        break;
      }
    }
  } catch (error) {
    console.error('发送交易时出错:', error);
  }
}

// 执行转账操作
main();
